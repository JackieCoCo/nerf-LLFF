.. _changelog:

Changelog
=========

.. include:: ../CHANGELOG.txt
