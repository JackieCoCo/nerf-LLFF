int boundary_points = 0;
int spectral_initialization = 0;
int cutType = 0;
int memory_saving = 0;
